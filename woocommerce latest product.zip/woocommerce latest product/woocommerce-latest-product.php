<?php

/*
Plugin Name:       Woocommerce Latest Product
Plugin URI:        https://devles.com/
Description:       WooCommerce latest product show on any page or section by shorcode
Version:           1.0.0
Requires at least: 5.2
Requires PHP:      7.2
Author:            Rezwan Shiblu
Author URI:        https://devles.com/
Text Domain:       woocommerce-latest-product
License:           GPL v2 or later
License URI:       http://www.gnu.org/licenses/gpl-2.0.txt

Woocommerce Latest Product is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 2 of the License, or
any later version.
 
Woocommerce Latest Product is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
GNU General Public License for more details.
 
You should have received a copy of the GNU General Public License
along with Woocommerce Latest Product. If not, see http://www.gnu.org/licenses/gpl-2.0.txt.
*/

/**
 * Check Woocommerce active or not
 */

/**
 * Check if WooCommerce is activated
 */
if ( ! function_exists( 'is_woocommerce_activated' ) ) {
	function is_woocommerce_activated() {
		if ( class_exists( 'woocommerce' ) ) { return true; } else { return false; }
	}
}

/**
 * Product Query Using a Shortcode to Display
 */

add_shortcode( 'rz_woocommerce_latest_product', 'rz_product' );
function rz_product() {
	?>
<!-- <ul class="products"> -->	
	<?php
    $args = array(
			'post_type' => 'product',
			'posts_per_page' => 4
			);
    $q = new WP_Query( $args );
    

    $q = new WP_Query( $args );
		if ( $q->have_posts() ) {
			while ( $q->have_posts() ) : $q->the_post();
				wc_get_template_part( 'content', 'product' );
			endwhile;
		} else {
			echo __( 'No products found' );
		}
		wp_reset_postdata();
		?>		
<!-- </ul> -->
<?php		
}


